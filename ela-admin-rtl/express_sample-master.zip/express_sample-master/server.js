require('dotenv').config();
const run = require('./src/app.js');
run();
// run app