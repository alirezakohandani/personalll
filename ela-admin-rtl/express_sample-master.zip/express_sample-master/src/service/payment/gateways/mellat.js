const startPayment = () => { };
const verifyPayment = () => { };
const settlePayment = () => { };