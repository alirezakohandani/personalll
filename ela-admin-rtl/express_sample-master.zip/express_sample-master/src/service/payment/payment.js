const doPayment = (method) => {


};